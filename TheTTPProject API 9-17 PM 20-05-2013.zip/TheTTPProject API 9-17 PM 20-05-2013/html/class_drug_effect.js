var class_drug_effect =
[
    [ "DrugEffect", "class_drug_effect.html#a603a1301c24c987bbe85152143a09762", null ],
    [ "Duplicate", "class_drug_effect.html#a47096352cd51ec3981861c68956ad27d", null ],
    [ "ToString", "class_drug_effect.html#a47d29362ed84e562e835c358a9962929", null ],
    [ "baseStrength", "class_drug_effect.html#a5bcb05f0bb425136f62aac0668d49638", null ],
    [ "effect", "class_drug_effect.html#a1a13bd2190def723eafe2f4ccc356051", null ],
    [ "multiplier", "class_drug_effect.html#aa65c533044b16f12d43d930edaaf48ab", null ],
    [ "timeRemaining", "class_drug_effect.html#a2c2fa3c8264e25ea7b54c29d55a1f3df", null ],
    [ "totalTime", "class_drug_effect.html#a788832ca4a9b7c7649f3dbcb1738a691", null ],
    [ "UID", "class_drug_effect.html#aa23209fcd34345e3cfab5a0a116a3179", null ]
];