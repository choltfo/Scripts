var class_ammo_pickup =
[
    [ "Interact", "class_ammo_pickup.html#a20ab491d251bae92212f132b26bf4f43", null ],
    [ "ammoType", "class_ammo_pickup.html#aac6d6d0711b43aaa3bbee9737bc3f02f", null ],
    [ "Bullets", "class_ammo_pickup.html#aa61030f3a5e81f16d002163410b32969", null ],
    [ "infinite", "class_ammo_pickup.html#a66b3d6d1f080bcafe01995c13bb08742", null ]
];