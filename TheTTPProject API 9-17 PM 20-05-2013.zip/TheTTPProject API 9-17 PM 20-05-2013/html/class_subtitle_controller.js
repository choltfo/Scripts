var class_subtitle_controller =
[
    [ "setLines", "class_subtitle_controller.html#a96caa1cf178605e627635afed0f7ad8b", null ],
    [ "lines", "class_subtitle_controller.html#a841f04dc828dbb8554d3734c933ad2b3", null ],
    [ "textStyle", "class_subtitle_controller.html#a9dc7de0be637215db97c493bf1c0d7e6", null ]
];