var class_hit_noises =
[
    [ "clip", "class_hit_noises.html#a61d7e456cdfc919a5a4c9ec0d47aa9fe", null ],
    [ "source", "class_hit_noises.html#ae1517e969152db67b3e7b037545769cb", null ]
];