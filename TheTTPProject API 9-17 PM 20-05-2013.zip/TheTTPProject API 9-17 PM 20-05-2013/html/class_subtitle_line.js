var class_subtitle_line =
[
    [ "name", "class_subtitle_line.html#ac7462dedccd6659ff81e54178aaec7db", null ],
    [ "text", "class_subtitle_line.html#a17c8ce1918ab96ee85340f6912d734a5", null ],
    [ "time", "class_subtitle_line.html#adea1b20875bd456349a34c91cf7a3135", null ]
];