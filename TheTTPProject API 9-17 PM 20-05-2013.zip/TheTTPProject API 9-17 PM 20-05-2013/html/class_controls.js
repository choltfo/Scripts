var class_controls =
[
    [ "aim", "class_controls.html#a8c9fd12d6dd4d362aa783c463f88db94", null ],
    [ "drop", "class_controls.html#a4aba5b82c9249606ae8dbe80d702dc09", null ],
    [ "fire", "class_controls.html#ac49d6fa7eb5cab470a6d15474999dc55", null ],
    [ "flashlight", "class_controls.html#a6aa29cdb46ea9c8a6b06d41e92d7968e", null ],
    [ "grenade", "class_controls.html#aeeb3edb51ebcb37795ee15d69b75716d", null ],
    [ "interact", "class_controls.html#ab64a6ec3f57ddfc69ed847368d52d196", null ],
    [ "jump", "class_controls.html#a516c6237d3ac1c2832a1794db4133f25", null ],
    [ "melee", "class_controls.html#aea659b97c55a76d29b16af75da6b6942", null ],
    [ "minimap", "class_controls.html#a42a56c6d668680243e9e1056e9e25382", null ],
    [ "objectiveDetails", "class_controls.html#a00336430df21b7276d3a2557e5f026b0", null ],
    [ "pause", "class_controls.html#af45726691f4480eb1efe0d55bc1e7388", null ],
    [ "reload", "class_controls.html#a77a58ec852cb7070a83df06f931fcd84", null ],
    [ "switchWeapons", "class_controls.html#a093e3bc21179a1021279b12103687d96", null ],
    [ "weapon0", "class_controls.html#af12fccefc212c63cdb5e2d3135df1407", null ],
    [ "weapon1", "class_controls.html#a225d52a54997fb49a779fc7d95dcfb06", null ]
];