var class_camera_fade =
[
    [ "SetScreenOverlayColor", "class_camera_fade.html#ad4fa470e5e718574ba170ebaf14be902", null ],
    [ "StartFade", "class_camera_fade.html#a12c2214fe39a0bc66db934c9fa30b392", null ]
];