var class_pickup_objective =
[
    [ "Interact", "class_pickup_objective.html#ac577aa1a0bbb5a07cbac57c6bfd73713", null ]
];