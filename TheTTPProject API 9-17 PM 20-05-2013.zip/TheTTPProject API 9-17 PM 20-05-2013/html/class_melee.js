var class_melee =
[
    [ "damage", "class_melee.html#a5fdbad5bc899e2d6b5de59e2299eb761", null ],
    [ "fist", "class_melee.html#aa348f8d86c9e40f6e8fc4e6b087b90b0", null ],
    [ "knockback", "class_melee.html#a882bb929f1fe24e256894b5d7484a5f8", null ],
    [ "LFAnimX", "class_melee.html#ad3a1c4c026a0424ce6a9a5b65ac7f73d", null ],
    [ "LFAnimY", "class_melee.html#a927c8bbc068fe2fb299004ee2a131de4", null ],
    [ "LFAnimZ", "class_melee.html#aa937e95956cebc179239c5354d36a5cf", null ],
    [ "RFAnimX", "class_melee.html#a01d466e2e640880edcbafc1f7e486f82", null ],
    [ "RFAnimY", "class_melee.html#afaaa3bc435b3d7b58a126acb397bf567", null ],
    [ "RFAnimZ", "class_melee.html#a3045b18abc5d45c60c57cfeb9edb9782", null ],
    [ "weaponController", "class_melee.html#aeb1242c5adfe7ab2ae805e36af38ca66", null ]
];