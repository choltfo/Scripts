var class_pause =
[
    [ "audioLis", "class_pause.html#a3dd624c4b2eaabffe3d6ce91790f96d4", null ],
    [ "controls", "class_pause.html#a175f854ea1fd8980a1370918573f91fc", null ],
    [ "deathScreenColor", "class_pause.html#a70c0f05bc232d31d3cd7ba1949b03b70", null ],
    [ "deathScreenStyle", "class_pause.html#aebe94f263f06bc464aa05ff2fcd57bec", null ],
    [ "fader", "class_pause.html#a8bf9fd33953a4f19006f023334dd7896", null ],
    [ "itemHeight", "class_pause.html#a029c50e36052167e7d8ca8af16a4d086", null ],
    [ "itemWidth", "class_pause.html#a766f201dbb19376bc78c64222dae7b7b", null ],
    [ "pane", "class_pause.html#a3158805ae8f5ec4ae2ab48a603c3bf01", null ],
    [ "paneLabelStyle", "class_pause.html#a97bc299e39665969b878ad3dec2b885a", null ]
];