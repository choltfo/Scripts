var class_area_objective =
[
    [ "player", "class_area_objective.html#afd83b15c632b1b79bedf33f944856e97", null ]
];