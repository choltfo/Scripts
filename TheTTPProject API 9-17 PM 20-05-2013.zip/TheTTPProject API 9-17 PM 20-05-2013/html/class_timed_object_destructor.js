var class_timed_object_destructor =
[
    [ "Start", "class_timed_object_destructor.html#acac9a6a62f92dc860271166c11aeeedb", null ],
    [ "secondsToDestroy", "class_timed_object_destructor.html#aad53ff71ecbaffe18e332e4c6680b410", null ]
];