var class_enemy =
[
    [ "health", "class_enemy.html#a479176322cef88e2129b28015a509e54", null ],
    [ "isPaused", "class_enemy.html#a30936470cb56dbea8b0afc0f3cc2d48b", null ],
    [ "motor", "class_enemy.html#a8efbe00e4f30df7a8d3deee7dbd217ed", null ],
    [ "player", "class_enemy.html#a926052313f0d8487762ac265cf2e2409", null ],
    [ "usefulnessScale", "class_enemy.html#a79310dbcc2c5ba6bdd8076e6de264a8d", null ]
];