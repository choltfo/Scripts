var class_mouse_look_modded =
[
    [ "RotationAxes", "class_mouse_look_modded.html#aa27f2ccc7a5ea4fb6f51297f9d53939f", [
      [ "MouseXAndY", "class_mouse_look_modded.html#aa27f2ccc7a5ea4fb6f51297f9d53939fa109431b32c091e8a7ad541546c66c522", null ],
      [ "MouseX", "class_mouse_look_modded.html#aa27f2ccc7a5ea4fb6f51297f9d53939fabf27c48f8a38ed19eeeba089dd8d3ba1", null ],
      [ "MouseY", "class_mouse_look_modded.html#aa27f2ccc7a5ea4fb6f51297f9d53939fa73843207a289db41b16a5bb8254ca425", null ]
    ] ],
    [ "axes", "class_mouse_look_modded.html#a91e8817b5f8bcab93c453a012525e5ec", null ],
    [ "maximumX", "class_mouse_look_modded.html#a2af55e03918ab82938b00c9d08890fc7", null ],
    [ "maximumY", "class_mouse_look_modded.html#afa99d995d120d79685aa12ac691aebb2", null ],
    [ "minimumX", "class_mouse_look_modded.html#a5adb6d86f4a166e081b781bce768d151", null ],
    [ "minimumY", "class_mouse_look_modded.html#a7a220eb31c968a6af276a1449b58eaca", null ],
    [ "rotationY", "class_mouse_look_modded.html#ad5fd93d3dff5a9e2a779977a4bf54fb2", null ],
    [ "sensitivityX", "class_mouse_look_modded.html#a91661b186f3b88866c3cb8e017c3694b", null ],
    [ "sensitivityY", "class_mouse_look_modded.html#a5a0dec34b7ecb68c3dc24f3cb67724fb", null ]
];