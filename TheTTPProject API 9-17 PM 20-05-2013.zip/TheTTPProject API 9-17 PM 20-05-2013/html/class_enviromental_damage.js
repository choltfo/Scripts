var class_enviromental_damage =
[
    [ "damageOccurDelay", "class_enviromental_damage.html#aad803a2bd650470a809f5b591c5d66ba", null ],
    [ "health", "class_enviromental_damage.html#a973eaf67b87b3293b0003307fe2bd604", null ],
    [ "lastDamageTime", "class_enviromental_damage.html#ae41e8d25c0268f7d56838ae24db26abb", null ]
];