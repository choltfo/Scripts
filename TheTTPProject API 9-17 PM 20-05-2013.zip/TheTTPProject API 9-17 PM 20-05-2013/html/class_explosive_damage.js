var class_explosive_damage =
[
    [ "explode", "class_explosive_damage.html#a71400f8afeab35767c00cfa6ab20aac2", null ],
    [ "blown", "class_explosive_damage.html#a1ab0e268ceb9771dc79d62c0e82842f3", null ],
    [ "maxDamage", "class_explosive_damage.html#a306c629d2528febc49c1f17977201264", null ],
    [ "range", "class_explosive_damage.html#afce330bd97df0ea6fe0276752fd62df6", null ]
];