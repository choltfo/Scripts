var class_health =
[
    [ "Damage", "class_health.html#a4a9abe4143809419d4b8e3d34410d52a", null ],
    [ "Damage", "class_health.html#ab7ca193dfba039025a2f1f40379b5fb5", null ],
    [ "OnGUI", "class_health.html#a7dcbbe5118be4d57c890c03813b9e511", null ],
    [ "Start", "class_health.html#a31ffeaccdd59ab1f570db4fea02ff6cf", null ],
    [ "Update", "class_health.html#a366b149e3af33a37ec985c861aaa3f6e", null ],
    [ "bloodSplatter", "class_health.html#aacd5e6447eed31669df53a2c898e3c38", null ],
    [ "DeathScreen", "class_health.html#aa9527890a1be1d60fed58f5c67f7ba0f", null ],
    [ "drawTextures", "class_health.html#a4d9e55766f1cfb2328442ad23a15c320", null ],
    [ "fadeColor", "class_health.html#a11618f7fd94b51784a7503e802317fee", null ],
    [ "fader", "class_health.html#abeb662de319d473cea50daceecf95cfb", null ],
    [ "fadeTime", "class_health.html#a52430b4bd26d95c441631b94e6662312", null ],
    [ "healDelay", "class_health.html#a71fabdb112d257f570276cd5b31b8345", null ],
    [ "healRate", "class_health.html#adf913ec8520ea69f7dd5e515df307cf1", null ],
    [ "HealthLevel", "class_health.html#ab0deb320491706c13b95b1e746aa354b", null ],
    [ "MaxHealth", "class_health.html#a6c386f61a81761ef60ccb9389407d70c", null ],
    [ "painSounds", "class_health.html#a4eca6c5465bdc5ecf363c0837c7f8480", null ],
    [ "painSoundSource", "class_health.html#a5560e7dbd521c35a59af86f62c2fbdaa", null ],
    [ "pauseController", "class_health.html#aed6879f3aa003b546e18561da7074d6f", null ],
    [ "playSounds", "class_health.html#a0b2b6a3af7420724be9b0245461e4f4b", null ],
    [ "transparent", "class_health.html#ab013786c25b44a8d55142b746ebd8fc2", null ]
];