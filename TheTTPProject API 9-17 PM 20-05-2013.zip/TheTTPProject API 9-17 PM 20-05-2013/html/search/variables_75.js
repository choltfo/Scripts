var searchData=
[
  ['uid',['UID',['../class_drug_effect.html#aa23209fcd34345e3cfab5a0a116a3179',1,'DrugEffect']]],
  ['usefulnessscale',['usefulnessScale',['../class_enemy.html#a79310dbcc2c5ba6bdd8076e6de264a8d',1,'Enemy']]]
];
