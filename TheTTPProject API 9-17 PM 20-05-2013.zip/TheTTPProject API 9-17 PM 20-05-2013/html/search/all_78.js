var searchData=
[
  ['xspread',['xSpread',['../class_underbarrel_attachment.html#a50de67aa7ddbdff20d309ba0e3b9ea02',1,'UnderbarrelAttachment.xSpread()'],['../class_weapon.html#a710c581664eea4c42f9cd80005e77217',1,'Weapon.xSpread()']]]
];
