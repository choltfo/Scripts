var searchData=
[
  ['drugdosage',['DrugDosage',['../class_drug_dosage.html',1,'']]],
  ['drugeffect',['DrugEffect',['../class_drug_effect.html',1,'']]]
];
