var searchData=
[
  ['nightlight',['nightlight',['../class_sleep.html#af00e26c5eb15c93f6b826342131647eb',1,'Sleep']]],
  ['nightmaterial',['nightMaterial',['../class_sleep.html#a14fdd4c67bc2199a5fbc3d134eeb46ea',1,'Sleep']]],
  ['normalzoom',['NormalZoom',['../class_underbarrel_attachment.html#aa8d71d94381ac5bdcbbbce5c1efda062',1,'UnderbarrelAttachment.NormalZoom()'],['../class_weapon.html#a1b1a57ce37434aa290cfcb4593d4dd38',1,'Weapon.NormalZoom()']]],
  ['numofshots',['numOfShots',['../class_underbarrel_attachment.html#ad89dbea0d9f6e049e049041fea33c4f6',1,'UnderbarrelAttachment.numOfShots()'],['../class_weapon.html#ad0c77c42fc853d35b753be4e0ba31f74',1,'Weapon.numOfShots()']]]
];
