var searchData=
[
  ['gunangle',['gunAngle',['../class_underbarrel_attachment.html#a8c4c40aae7967b7664bf8afc65e88a9a',1,'UnderbarrelAttachment.gunAngle()'],['../class_weapon.html#ac26ab8688bb759b75f1294c261414cad',1,'Weapon.gunAngle()']]],
  ['gunclimb',['GunClimb',['../class_underbarrel_attachment.html#a42d9e99add7edff1eaca8d64a143179d',1,'UnderbarrelAttachment']]],
  ['gundistance',['gunDistance',['../class_underbarrel_attachment.html#afe18e2b34a641d282437a83a1b573141',1,'UnderbarrelAttachment.gunDistance()'],['../class_weapon.html#a85f7dac51aee57981a627362c908c093',1,'Weapon.gunDistance()']]]
];
