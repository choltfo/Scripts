var class_drug_dosage =
[
    [ "addEffect", "class_drug_dosage.html#af1824124cfa3e1b7f16062895cd65343", null ],
    [ "charControls", "class_drug_dosage.html#a70de2a48845a2c4f0e76ec446cd80cf4", null ],
    [ "condemn", "class_drug_dosage.html#a2167b888fa89dbf04d78c99468fde5c7", null ],
    [ "effects", "class_drug_dosage.html#a794b9474496faa1e3fa7b1ae0dd793b3", null ],
    [ "healthManager", "class_drug_dosage.html#a6c7454451855e4640db5e86a54955554", null ],
    [ "Recoil", "class_drug_dosage.html#a4227fab30ad204afad447ada5046aa45", null ],
    [ "Slowness", "class_drug_dosage.html#a591be06addd0ca634f0fdd74b59acca3", null ],
    [ "SlownessLevel", "class_drug_dosage.html#aaea5d81ecdc7ff58c5e10430db9e4ac0", null ],
    [ "SlownessLevelVSSlowness", "class_drug_dosage.html#a673e12e357e4cb529c2e780424a7d98a", null ]
];