var class_character_controls =
[
    [ "canJump", "class_character_controls.html#a262778c37ba4e6e976f971fb227c6f24", null ],
    [ "gravity", "class_character_controls.html#ae6160202b73c2f6bfd56fbf49f0e1ccc", null ],
    [ "jumpHeight", "class_character_controls.html#a6215b31e74c81c183106163357007478", null ],
    [ "maxVelocityChange", "class_character_controls.html#a8b52d01b85ce84aef226505bf4ce2675", null ],
    [ "speed", "class_character_controls.html#a586213ef74a36ffa73214dbd002e2ed6", null ],
    [ "vehicle", "class_character_controls.html#a063a0561f80bd6d7ebc8ba1c99d004fa", null ]
];