var class_vehicle =
[
    [ "activate", "class_vehicle.html#a7917289bc4232efd6551fd0a262fb213", null ],
    [ "deactivate", "class_vehicle.html#ac030e860196dd0dd34d60b17be4cdac8", null ],
    [ "controls", "class_vehicle.html#a005a87ed4e5e41d324cf222db1b39ad5", null ],
    [ "ExitLocation", "class_vehicle.html#aa14a1c95304352c5da4292d548579ee3", null ],
    [ "isActive", "class_vehicle.html#af69633516f323af8c5580868e1a69960", null ],
    [ "isOccupied", "class_vehicle.html#a89ce99ab5f4d5dd77ccd36741c4deb61", null ],
    [ "player", "class_vehicle.html#ad66ae02a25c49153b3120689f7ac1081", null ],
    [ "VControls", "class_vehicle.html#a037a66817d91e878d9d674ac84345406", null ]
];