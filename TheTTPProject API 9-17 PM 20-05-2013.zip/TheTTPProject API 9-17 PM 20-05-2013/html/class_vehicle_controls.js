var class_vehicle_controls =
[
    [ "accelerator", "class_vehicle_controls.html#a8ae6110497be10ab8a78457ceb7c31e3", null ],
    [ "controls", "class_vehicle_controls.html#a7cee9a653a83e3bf372f363140127df2", null ],
    [ "crashMagnitude", "class_vehicle_controls.html#a2231f857b32bfed20c31c8945bf1e8d5", null ],
    [ "DEAD", "class_vehicle_controls.html#a2c121d5d49f927d82f2e8165b2454eb8", null ],
    [ "descentSpeed", "class_vehicle_controls.html#ab5a7db0008f03b72f4d03e2a66830dbe", null ],
    [ "distToGround", "class_vehicle_controls.html#a83b1e9b52e7224eec460a37eb7ae46d6", null ],
    [ "downThreshold", "class_vehicle_controls.html#a99d1149441d1568adf1eb5282df862f2", null ],
    [ "gravity", "class_vehicle_controls.html#ad3b4b20853989c56550291150ba0cf71", null ],
    [ "handling", "class_vehicle_controls.html#a71201266a10ff7365c536a567c99b49f", null ],
    [ "isCarActive", "class_vehicle_controls.html#ab6b4112f694b86dec97436389ef7913d", null ],
    [ "lastTouch", "class_vehicle_controls.html#aedba365fe015a6062b70272554d68090", null ],
    [ "maxReverseSpeed", "class_vehicle_controls.html#a6c273943cd4627de39b8cb1e5a7ab815", null ],
    [ "maxSpeed", "class_vehicle_controls.html#a8eb15646654b4d74c918820dba249da0", null ],
    [ "previousVelocity", "class_vehicle_controls.html#a01df7229b3da05b8f964ea1e7b276366", null ],
    [ "speed", "class_vehicle_controls.html#a83bd2b635f65921c52a3e01107ac31e1", null ],
    [ "steering", "class_vehicle_controls.html#aabc77151e607ee10a7bca5d4cfaf245a", null ],
    [ "turning", "class_vehicle_controls.html#a4d3c3644f45e5d5b1c06d17a943ca9c3", null ]
];