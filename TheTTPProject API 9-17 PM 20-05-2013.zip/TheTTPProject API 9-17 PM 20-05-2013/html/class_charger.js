var class_charger =
[
    [ "activationDistance", "class_charger.html#a5552380cc49f73fc1a252fbd33953aa0", null ],
    [ "collideEffect", "class_charger.html#a1eb801146c3754cad667cef18aa0e4a2", null ],
    [ "damage", "class_charger.html#ac7ff2b57579e34f1d697ecba0fa57002", null ],
    [ "effectDelay", "class_charger.html#a8f2e1756e5a7a07bae137e83fa3fd756", null ],
    [ "recentEffectTime", "class_charger.html#aa2c8fd821b10e18c1d93e258656b68c4", null ]
];