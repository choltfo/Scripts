var class_sleep =
[
    [ "Interact", "class_sleep.html#aaf8364c7ae9f8e537813ff20b3c68d1f", null ],
    [ "clearColor", "class_sleep.html#a95dc0bbe517472278808f296b18f26bc", null ],
    [ "daylight", "class_sleep.html#a638f61a9cf33e8d58fcb780b7b367f75", null ],
    [ "dayMaterial", "class_sleep.html#a86883db72f1cbb392b9954ec0b266063", null ],
    [ "fadeColor", "class_sleep.html#acff42db6e453983e9bff5d7bfd593f29", null ],
    [ "fader", "class_sleep.html#a326ca64c0b496681c8bf4b002bb88a82", null ],
    [ "fadeTime", "class_sleep.html#a85439cad9bbf9f6f4c53ea323d40270d", null ],
    [ "nightlight", "class_sleep.html#af00e26c5eb15c93f6b826342131647eb", null ],
    [ "nightMaterial", "class_sleep.html#a14fdd4c67bc2199a5fbc3d134eeb46ea", null ]
];